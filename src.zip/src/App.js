import logo from './logo.svg';
import './App.css';
import LandingPage from './LandingPage/LandingPage';
import { Route, Routes } from 'react-router-dom';
import FlexComponent from './page1';
import CandidateProfile from './classComponent/Matrimony';
import NotifictionComponent from './notificationComponent';
import DashboardComponent from './Dashboard/Dashboard';
import ProfilePageComponent from './Profilepage/ProfilepageComponent';
import SignupComponemt from './classComponent/signUpComponent/signupComponent';
import RegistrationForm from './classComponent/signUpComponent/RegistrationComponent';
import ProfileSettingsPage from './ProfileUpdateSettings/ProfileSettings';

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<LandingPage />} />
      <Route path="page1" element={<FlexComponent />} />
      <Route path="Dashboard/:id" element={<ProfilePageComponent />} />
      <Route path="notify" element={<NotifictionComponent />} />
      <Route path="/Dashboard" element={<DashboardComponent />} />
      <Route path="sign" element={<SignupComponemt />} />
      <Route path="reg" element={<RegistrationForm />}/>
      <Route path="settings" element={<ProfileSettingsPage />} />
      </Routes>
    </div>
  );
}

export default App;
