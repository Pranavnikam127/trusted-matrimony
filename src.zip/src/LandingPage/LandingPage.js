import React from 'react'
import LandingHeader from './LandingContain/LandingHeader/LandingHeader'
import LandingContain from './LandingContain/LandingContain/LandingContain'
import LandingFooter from './LandingContain/LandingFooter/LandingFooter'

const LandingPage = () => {
  return (
    <div>
        <LandingHeader/>
        <LandingContain/>
        <LandingFooter/>
    </div>
  )
}

export default LandingPage