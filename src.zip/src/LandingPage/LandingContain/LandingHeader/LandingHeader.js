import React from 'react';
import logo from './logo-matrimony-header.png';
import { Link } from 'react-router-dom';
import { BellFill } from 'react-bootstrap-icons';
import './LandingHeader.css';

const LandingHeader = () => {
  return (
    <header className='Landing-Main-Header'>
        <div className='Landing-Header-logo'>
            <img src={logo} alt='logo'/>
            <Link to="/"><h1 className='heading'>Trusted Matrimony</h1></Link>
            {/* <Link to="/notify">
               <BellFill />
            </Link> */}
        </div>
    </header>
  )
}

export default LandingHeader