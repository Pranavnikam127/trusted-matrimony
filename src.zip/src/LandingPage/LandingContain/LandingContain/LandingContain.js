import React, { useState } from 'react'
import './LandingContain.css'
import { Link } from 'react-router-dom'
import ModalComponent1 from '../../../modalComponent1';
import SignupComponemt from '../../../classComponent/signUpComponent/signupComponent';

const LandingContain = () => {
    const [showSignUpModal, setShowSignUpModal] = useState(false);
    const setSignUpModal = (openOrClose) =>{
        console.log("called");
        setShowSignUpModal(openOrClose);
    }
  return (
    <div className='Landing-Contain'>
       <div className="Login-Container">
            <h2>Login</h2>
            <div class="Login-input">
                <div class="inputBox">
                    <label for="">Username</label>
                    <input type="text"/>
                </div>
                <div class="inputBox">
                    <label for="">Password</label>
                    <input type="password"/>
                </div>
                <div class="inputBox">
                    <Link to="/Dashboard"><input type="submit" name="" value="LOG IN"/></Link>
                </div>
            </div>
            <p class="forgot">Don't Have Account? <Link to="/reg">Sign Up</Link></p>
            {
                showSignUpModal && 
                <ModalComponent1 type={"Sign In"} open={showSignUpModal} close={setSignUpModal}/>
            }     
        </div>
    </div>
  )
}

export default LandingContain