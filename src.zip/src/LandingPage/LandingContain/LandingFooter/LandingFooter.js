import React from 'react'
import './LandingFooter.css'

const LandingFooter = () => {
  return (
       <div className="copyright-area">
              <div className="copyright-text">
                 <p>&copy; Copyright 2023 | All Right Reserved By  <a href="https:www.zonsofttech.com"> ZON-SOFT TECH</a></p>
              </div>
       </div>
  )
}

export default LandingFooter