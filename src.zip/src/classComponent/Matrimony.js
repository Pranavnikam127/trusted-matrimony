import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { candidates } from "./dummyData/candidatesProfile";

const CandidateProfile = (props) =>{
   const params = useParams();
   const newCandidates = candidates;
   const [profile, setProfile] = useState();
   console.log(params)
   useEffect(()=>{
     filterProfile(params.id)
   },[])
   const filterProfile = (id) =>{
      let profile = newCandidates.filter((candidate)=>{
         return candidate.id === id;
      });
      setProfile(profile[0]);
   }
   return(
      <div>
         hello profile {profile && profile.id}<br />
         {profile && profile.name}<br />
         {profile && profile.education}
         
      </div>
   )
}
export default CandidateProfile;
