export const motherTongues =[
    {
        motherTongueName:"Marathi"
    },
    {
        motherTongueName:"Hindi"
    }, {
        motherTongueName:"Punjabi"
    }, {
        motherTongueName:"Bengali"
    }, {
        motherTongueName:"Gujarati"
    }, {
        motherTongueName:"Urdu"
    }, {
        motherTongueName:"Telgu"
    }, {
        motherTongueName:"Kannada"
    }, {
        motherTongueName:"English"
    }, {
        motherTongueName:"Tamil"
    }, {
        motherTongueName:"Oriya"
    }, {
        motherTongueName:"Marwari"
    }, {
        motherTongueName:"Aca"
    }, {
        motherTongueName:"Arabic"
    }, {
        motherTongueName:"Arunachalli"
    }, {
        motherTongueName:"Assamese"
    }, {
        motherTongueName:"Awadhi"
    }, {
        motherTongueName:"Baluchi"
    }, {
        motherTongueName:"Bhojpuri"
    }, {
        motherTongueName:"Bhutia"
    },
    {
        motherTongueName:"Burmese"
    },
    {
        motherTongueName:"Chattisgarhi"
    },
    {
        motherTongueName:"Malayalam"
    },{
        motherTongueName:"Manipuri"
    },
    {
        motherTongueName:"Odia"
    },{
        motherTongueName:"Khandeshi"
    },
    {
        motherTongueName:"Others"
    },
]