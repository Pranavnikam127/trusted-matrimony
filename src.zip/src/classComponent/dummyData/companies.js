export const companies=[
    {
       companyName:"TCS"
    },
    {
        companyName:"Infosys"
     }, {
        companyName:"Wipro"
     }, {
        companyName:"Google"
     }, {
        companyName:"Microsoft"
     }, {
        companyName:"Accenture"
     }, {
        companyName:"Capgemini"
     }, {
        companyName:"Syngenta"
     }, {
        companyName:"Mcure"
     }, {
        companyName:"Mahindra"
     }, {
        companyName:"Oracle"
     }, {
        companyName:"Cognizant"
     }, {
        companyName:"Cipla"
     }, {
        companyName:"Lupin"
     }, {
        companyName:"Sun Pharmaceutical Industries Ltd."
     },  {
        companyName:"Zydus Cadila healthcare"
     },  {
        companyName:"Others"
     }, 
]