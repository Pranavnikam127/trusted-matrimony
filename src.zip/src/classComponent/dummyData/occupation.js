export const fathersOccupation=[
    {
        fatherOccupation:"Government Servant"
    },
    {
       fatherOccupation:"Engineer"
    },
    {
        fatherOccupation:"Farmer"
     },{
        fatherOccupation:"Business Man"
     },{
        fatherOccupation:"Professor"
     },{
        fatherOccupation:"Others"
     },
]
export const Occupation=[
    {
    occupation:"Engineer"
    },
    {
     occupation:"Doctor"
     },
    {
     occupation:"Professor"
    },
    {
        occupation:"Gov. Servant"
    },{
        occupation:"Others"
       },
]
export const mothersOccupation=[
    {
       motherOccupation:"Government Servant"
    },{
        motherOccupation:"Engineer"
     },{
        motherOccupation:"Housewife"
     },{
        motherOccupation:"Professor"
     },{
        motherOccupation:"Others"
     },
]

export const familyIncome=[
    {
      income:"0-100000"  
    },{
        income:"100000-1000000"  
      },{
        income:"10000000-above"  
      },
]
export const highestEducation=[
    {
        education:"10th"
    },{
        education:"12th"
    },{
        education:"UG"
    },{
        education:"PG"
    },{
        education:"Others"
    },
]
export const UGDegree=[
    {
       ugDegree:"BSC"
    },{
        ugDegree:"BA"
     },{
        ugDegree:"BCOM"
     },{
        ugDegree:"BTECH"
     },{
        ugDegree:"BE"
     },{
        ugDegree:"others"
     },
]
export const PGDegree=[
    {
       pgDegree:"MSC"
    },{
        pgDegree:"MA"
     },{
        pgDegree:"MCOM"
     },{
        pgDegree:"MTECH"
     },{
        pgDegree:"ME"
     },{
        pgDegree:"others"
     },
]
export const Age=[
    {
        age:"18-28"
    },{
        age:"28-38"
    },{
        age:"38-above"
    },
]
export const Religion=[
    {
        religion:"Hindu"
    }, {
        religion:"Muslim"
    }, {
        religion:"Christian"
    }, {
        religion:"Sikh"
    }, {
        religion:"Buddhist"
    }, {
        religion:"Jain"
    }, {
        religion:"Others"
    },
]
export const MaritalStatus=[
    {
      maritalStatus:"Married"
    }, {
        maritalStatus:"Unmarried"
      },
]
export const FamilyValues=[
    {
      familyValue:"Traditional"
    },{
        familyValue:"Moderate"
      },
]
export const Gender=[
    {
        gender:"Male"
    },
    {
        gender:"Female"
    },
]