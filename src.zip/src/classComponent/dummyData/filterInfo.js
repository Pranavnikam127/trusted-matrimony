export const ageFilter = [
{
    age:"18 to 28"
},
{
    age:"28 to 38"
},
{
    age:"38 to 48"
},
{ 
    age:"48 or above"
}
];
export const religionInfo = ["Hindu", "Muslim", "Christian", "Sikh", "Others"];
export const occFilter = ["Engineer", "Doctor", "Professor", "Buisness", "Others"];
export const eduFilter = ["UG", "PG", "PHD", "Others"];
export const manglikInfo = [{
    name: "manglik",
    id:"manglik",
    value:true,
    label:"Manglik"
},
{
    name: "manglik",
    id:"nonmanglik",
    value:false,
    label:"Non Manglik"
}]