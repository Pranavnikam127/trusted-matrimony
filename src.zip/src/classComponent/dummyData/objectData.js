export const data={
photo:" ",
name:" ",
age:" ",
manglik:" ",
gender:" ",
familyBackground:{
    fatherOccupation:" ",
    motherOccupation:" ",
    gotra:" ",
    familyIncome:" ",
    familyValues:" ",
    noOfSisters:" ",
    noOfBrothers:" "
},
educationAndCareer:{
    highestEducation:" ",
    ugDegree:" ",
    pgDegree:" ",
    employeeIn:" ",
    company:" ",
    income:" "
},
desiredPartner:{
    age:" ",
    height:" ",
    maritalStatus:" ",
    religion:" ",
    caste:" ",
    motherTongue:" ",
    income:" "
}
}