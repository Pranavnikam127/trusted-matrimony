import React from "react";

const LoginComponent = () =>{
    return(<>
        <div className="log">
  <h1><center>Login Component</center></h1>
  <div className="loginup2">
    <div className="loginup">
      Enter Username:
    </div>
    <div className="loginup1">
      <input type="text" /><br/>
    </div>
  </div>
  <div className="loginup2">
    <div className="loginup">
      Enter Password:
    </div>
    <div className="loginup1">
      <input type="password" /><br/>
    </div>
  </div>
  <div className="loginup2">
    <div className="loginup">
      <button>Submit</button>
    </div>
    <div className="loginup">
      <button>Cancel</button>
    </div>
  </div>
</div>
    </>
    )
}
export default LoginComponent