import React from "react";
import { data } from "../dummyData/objectData";
import { useState } from "react";
import { castes } from "../dummyData/castes";
import { motherTongues } from "../dummyData/motherTongue";
import { companies } from "../dummyData/companies";
import { FamilyValues, Gender, MaritalStatus, PGDegree, Religion, UGDegree, familyIncome, fathersOccupation, highestEducation, mothersOccupation,Age, Occupation} from "../dummyData/occupation";
import "./signComponent.css";
const SignupComponemt = () =>{
     const [profileObj,setProfileObj]= useState(data);
    const captureSignInInfo=(e)=>{
      //comment to commit changes
        let obj={...profileObj};
         if(e.target.getAttribute('section')){
            obj[e.target.getAttribute('section')]={...profileObj[e.target.getAttribute('section')]};
            obj[e.target.getAttribute('section')][e.target.name]=e.target.value;
         }
         else{
            obj[e.target.name]=e.target.value;
         }
         setProfileObj(obj);
         console.log(obj);
       }
    return(
        <>
           <div className="Signup-Main">
            <div className="Signup-Form">
           <div class="Sign-one">
        <h1 ><center>Registration form</center></h1>
        </div>
        <div class="sign">
            <div className="sign2">
                <div className="form">
                      <div className="s1">
                        Photo :
                      </div>
                      <div className="i1">
                        <input type="file" className="photo" onChange={(e)=>captureSignInInfo(e)} />
                      </div><br/>
                </div>
                     <div className="form">
                      <div className="s1">
                         Name:
                      </div>
                      <div className="i1">
                       <input type="text" className="name" onChange={(e)=>captureSignInInfo(e)} />
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                        Age :
                      </div>
                      <div className="i1">
                        <input type="text" name="age" onChange={(e)=>captureSignInInfo(e)} />
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                        Manglik :
                      </div>
                      <div className="i1">
                         <input type="radio" name="manglik" value={true} onChange={(e)=>captureSignInInfo(e)} />
                        <label for="maglik" className="i1">Yes</label>
                        <input type="radio" name="manglik" value={false} onChange={(e)=>captureSignInInfo(e)}/>
                        <label for="manglik" className="i1">No</label>
                      </div><br/>
                </div>
                 <div className="form">
                      <div className="s1">
                        Gender :
                      </div>
                      <div className="i1">
                         <select name="gender" id="gender" onChange={(e)=>captureSignInInfo(e)} >
                       <option>Select Gender</option>
                      {
                        Gender.map(obj=>{
                        return  <option value={obj.gender}>{obj.gender}</option>
                     })
                     }
        </select>
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                        Occupation :
                      </div>
                      <div className="i1">
                      <select name="occupation" id="occupation" onChange={(e)=>captureSignInInfo(e)} >
                        <option>Select occupation</option>
                          {
                           Occupation.map(obj=>{
                           return  <option value={obj.occupation}>{obj.occupation}</option>
                          })
                         }
                    </select>
                      </div><br/>
                </div>
                <div>
                    <h2> 
                        FAMILY BACKGROUND</h2>
                    </div>
                <div className="form">
                      <div className="s1">
                      <label for="occupation">  Father's Occupation :</label>
                      </div>
                      <div className="i1">
                      <select name="fatherOccupation" id="occupation" section="familyBackground" onChange={(e)=>captureSignInInfo(e)} >
                          <option>Select Occupation</option>
                            {
                               fathersOccupation.map(occupation=>{
                             return <option value={occupation.fatherOccupation}>{occupation.fatherOccupation}</option>
                           })
                         }
                      </select>
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                      <label for="occupation">  Mother's Occupation :</label>
                      </div>
                      <div className="i1">
                      <select name="motherOccupation" id="occupation" section="familyBackground" onChange={(e)=>captureSignInInfo(e)} >
                        <option>Select Occupation</option>
                          {
                              mothersOccupation.map(occupation=>{
                              return   <option value={occupation.motherOccupation}>{occupation.motherOccupation}</option>
                             })
                              }
                      </select>
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                        Gotra :
                      </div>
                      <div className="i1">
                      <input type="text" name="gotra" section="familyBackground" onChange={(e)=>captureSignInInfo(e)} />
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                      <label for="income"> Family Income :</label>
                      </div>
                      <div className="i1">
                      <select name="familyIncome" id="income" section="familyBackground" onChange={(e)=>captureSignInInfo(e)} >
                         <option>Select Income</option>
                          {
                             familyIncome.map(incObj=>{
                               return <option value={incObj.income}>{incObj.income}</option>
                                 })
                            }
                       </select>
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                      <label for="value"> Family Values :</label>
                      </div>
                      <div className="i1">
                      <select name="familyValue" id="value" section="familyBackground" onChange={(e)=>captureSignInInfo(e)} >
                        <option>Select Values</option>
                         {
                            FamilyValues.map(valobj=>{
                            return <option value={valobj.familyValue}>{valobj.familyValue}</option>
                             })
                         }
                      </select>
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                        No. Of Sister's :
                      </div>
                      <div className="i1">
                      <input type="number" name="noOfSisters" section="familyBackground" onChange={(e)=>captureSignInInfo(e)}/>
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                        No. Of Brother's :
                      </div>
                      <div className="i1">
                      <input type="number" name="noOfBrothers" section="familyBackground" onChange={(e)=>captureSignInInfo(e)}/>
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                      <label for="religion"> Religion :</label>
                      </div>
                      <div className="i1">
                      <select name="religion" id="religion" section="familyBackground" onChange={(e)=>captureSignInInfo(e)}>
                         <option>Select Religion</option>
                           {
                              Religion.map(relobj=>{
                                return  <option value={relobj.religion}>{relobj.religion}</option>
                                })
                             }
                        </select>
                      </div><br/>
                </div>
            </div>
            <div className="sign3">
            <div>
                    <h2>EDUCATION AND CAREER</h2>
                    </div>
                <div className="form">
                      <div className="s1">
                      <label for="degree">  Highest Education :</label>
                      </div>
                      <div className="i1">
                      <select name="highestEducation" id="degree" section="educationAndCareer" onChange={(e)=>captureSignInInfo(e)}>
                         <option>Select Education</option>
                          {
                             highestEducation.map(eduObj=>{
                              return  <option value={eduObj.education}>{eduObj.education}</option>
                             })
                            }
                         </select>
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                      <label for="degree"> UG Degree :</label>
                      </div>
                      <div className="i1">
                      <select name="ugDegree" id="degree" section="educationAndCareer" onChange={(e)=>captureSignInInfo(e)}>
                       {
                          UGDegree.map(degree=>{
                            return <option value={degree.ugDegree}>{degree.ugDegree}</option>
                           })
                          }
                      </select>
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                      <label for="degree"> PG Degree :</label>
                      </div>
                      <div className="i1">
                      <select name="pgDegree" id="degree" section="educationAndCareer" onChange={(e)=>captureSignInInfo(e)}>
                       {
                         PGDegree.map(degree=>{
                           return  <option value={degree.pgDegree}>{degree.pgDegree}</option>
                           })
                          }
                     </select>
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                        Employeed :
                      </div>
                      <div className="i1">
                      <input type="radio" name="employeeIn" section="educationAndCareer" value={true} onChange={(e)=>captureSignInInfo(e)}/>
                       <label for="emp">Yes</label>
                       <input type="radio" name="emp" value={false}/>
                       <label for="emp">No</label>
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                        Company :
                      </div>
                      <div className="i1">
                      <select name="company" id="company" section="educationAndCareer" onChange={(e)=>captureSignInInfo(e)}>
                     {
                        companies.map(company=>{
                          return  <option value={company.companyName}>{company.companyName}</option>
                        })
                        }
                    </select>
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                        Income :
                      </div>
                      <div className="i1">
                      <select name="income" id="income" section="educationAndCareer" onChange={(e)=>captureSignInInfo(e)}>
                       {
                          familyIncome.map(incobj=>{
                             return <option value={incobj.income}>{incobj.income}</option>
                           })
                         }
                     </select>
                      </div><br/>
                </div>
                <div>
                    <h2>DESIRED PARTNER</h2>
                    </div>
                <div className="form">
                      <div className="s1">
                      <label for="age"> Age :</label>
                      </div>
                      <div className="i1">
                      <select name="age" id="age" section="desiredPartner" onChange={(e)=>captureSignInInfo(e)}>
                       <option>Select age</option>
                        {
                          Age.map(ageobj=>{
                            return  <option value={ageobj.age}>{ageobj.age}</option>
                            })
                          }
                      </select>
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                      <label for="degree"> Height:</label>
                      </div>
                      <div className="i1">
                      <input type="number" name="height" section="desiredPartner" onChange={(e)=>captureSignInInfo(e)}/>
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                      <label for="maritalStatus"> Marital Status :</label>
                      </div>
                      <div className="i1">
                      <select name="maritalStatus" id="maritalStatus" section="desiredPartner" onChange={(e)=>captureSignInInfo(e)}>
                        <option>Select Status</option>
                         {
                            MaritalStatus.map(maritalobj=>{
                             return <option value={maritalobj.maritalStatus}>{maritalobj.maritalStatus}</option>
                              })
                           }
                  </select>
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                      <label for="religion"> Religion :</label>
                      </div>
                      <div className="i1">
                      <select name="religion" id="religion" section="desiredPartner" onChange={(e)=>captureSignInInfo(e)}>
                      <option>Select Religion</option>
                       {
                         Religion.map(relobj=>{
                          return  <option value={relobj.religion}>{relobj.religion}</option>
                           })
                         }
                     </select>
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                      <label for="caste"> Caste :</label>
                      </div>
                      <div className="i1">
                      <select name="caste" id="caste" section="desiredPartner" onChange={(e)=>captureSignInInfo(e)}>
                       {
                          castes.map(caste => {
                            return <option value={caste.casteName}>{caste.casteName}</option>
                             })
                          }
                      </select>
                      </div><br/>
                </div>
                <div className="form">
                      <div className="s1">
                      <label for="income"> Income :</label>
                      </div>
                      <div className="i1">
                      <select name="income" id="income" section="desiredPartner" onChange={(e)=>captureSignInInfo(e)}>
                       {
                         familyIncome.map(incobj=>{
                           return  <option value={incobj.income}>{incobj.income}</option>
                          })
                        }
                     </select>  
                      </div><br/>
                </div>
                </div>
        </div>
        <div className="s11">
       <center> <button class="button" type="submit" onClick={()=>captureSignInInfo()} >Submit</button></center>
        </div>
        </div>
            </div>   

        {/* <div className="sign">
        <div  ="ss1">
        <h1 ><center>Sign Up</center></h1>
        </div>
        <div className="sign1n">
        <div className="sign1">
        <div class="signup">
        
        <div className="photoform">
       Photo :<input type="file" className="photo" onChange={(e)=>captureSignInInfo(e)} /></div><br/>
        </div>
        <div class="signup">
        <div className="nameform">
        Name :<input type="text" className="name" onChange={(e)=>captureSignInInfo(e)} /></div><br/>
        </div>
        <div class="signup">
        <div className="form">
        Age :<input type="text" name="age" onChange={(e)=>captureSignInInfo(e)} /></div><br/>
        </div>
        <div class="signup">
        <div className="form">
            Manglik :<input type="radio" name="manglik" value={true} onChange={(e)=>captureSignInInfo(e)} />
            <label for="maglik">Yes</label>
            <input type="radio" name="manglik" value={false} onChange={(e)=>captureSignInInfo(e)}/>
            <label for="manglik">No</label>
            </div>
            <br />
        </div>
       
        <div class="signup">
        <div className="form">
        <label for="gender"> Gender :</label>
        <select name="gender" id="gender" onChange={(e)=>captureSignInInfo(e)} >
        <option>Select Gender</option>
            {
                Gender.map(obj=>{
                    return  <option value={obj.gender}>{obj.gender}</option>
                })
            }
        </select>
        </div>
        <br/>
        </div>
        <div class="signup">
        <div className="form">
        <label for="occupation"> Occupation :</label>
        <select name="occupation" id="occupation" onChange={(e)=>captureSignInInfo(e)} >
        <option>Select occupation</option>
            {
                Occupation.map(obj=>{
                    return  <option value={obj.occupation}>{obj.occupation}</option>
                })
            }
        </select>
        </div>
        <br/>
        </div>

        <div class="signup">
        <h2>FAMILY BACKGROUND :</h2>
        <div className="form">
        <label for="occupation">  Father's Occupation :</label>
        <select name="fatherOccupation" id="occupation" section="familyBackground" onChange={(e)=>captureSignInInfo(e)} >
        <option>Select Occupation</option>
           {
               fathersOccupation.map(occupation=>{
                return <option value={occupation.fatherOccupation}>{occupation.fatherOccupation}</option>
               })
           }
    </select>
    </div>
        <br/>
        </div>
        <div class="signup">
        <div className="form">
        <label for="occupation">  Mother's Occupation :</label>
        <select name="motherOccupation" id="occupation" section="familyBackground" onChange={(e)=>captureSignInInfo(e)} >
        <option>Select Occupation</option>
           {
            mothersOccupation.map(occupation=>{
                return   <option value={occupation.motherOccupation}>{occupation.motherOccupation}</option>
            })
           }
        </select>
        </div>
        <br/>
        </div>
        <div class="signup">
        <div className="form">
        Gotra :<input type="text" name="gotra" section="familyBackground" onChange={(e)=>captureSignInInfo(e)} /></div><br/>
        </div>
        <div class="signup">
        <div className="form">
        <label for="income"> Family Income :</label>
        <select name="familyIncome" id="income" section="familyBackground" onChange={(e)=>captureSignInInfo(e)} >
        <option>Select Income</option>
            {
                familyIncome.map(incObj=>{
                    return <option value={incObj.income}>{incObj.income}</option>
                })
            }
        </select>
        </div>
        <br/>
        </div>
        <div class="signup">
        <div className="form">
        <label for="value"> Family Values :</label>
        <select name="familyValue" id="value" section="familyBackground" onChange={(e)=>captureSignInInfo(e)} >
        <option>Select Values</option>
             {
                FamilyValues.map(valobj=>{
                    return <option value={valobj.familyValue}>{valobj.familyValue}</option>
                })
             }
        </select>
        </div>
        <br/>
        </div>
        <div class="signup">
        <div className="form">
        No. Of Sister's :<input type="number" name="noOfSisters" section="familyBackground" onChange={(e)=>captureSignInInfo(e)}/></div><br/>
        </div>
        <div class="signup">
        <div className="form">
        No. Of Brother's :<input type="number" name="noOfBrothers" section="familyBackground" onChange={(e)=>captureSignInInfo(e)}/></div><br/>
        </div>
        <div class="signup">
        <div className="form">
        <label for="religion"> Religion :</label>
        <select name="religion" id="religion" section="familyBackground" onChange={(e)=>captureSignInInfo(e)}>
            <option>Select Religion</option>
            {
                Religion.map(relobj=>{
                    return  <option value={relobj.religion}>{relobj.religion}</option>
                })
            }
        </select>
        </div>
        <br/>
        </div>
        </div>
        
        <div className="sign2">
        <div class="signup">
            <h2>EDUCATION AND CAREER</h2>
            <div className="form">
        <label for="degree">  Highest Education :</label>
        <select name="highestEducation" id="degree" section="educationAndCareer" onChange={(e)=>captureSignInInfo(e)}>
        <option>Select Education</option>
          {
            highestEducation.map(eduObj=>{
                return  <option value={eduObj.education}>{eduObj.education}</option>
            })
          }
        </select>
        </div>
        <br/>
        </div>
        <div class="signup">
        <div className="form">
        <label for="degree"> UG Degree :</label>
        <select name="ugDegree" id="degree" section="educationAndCareer" onChange={(e)=>captureSignInInfo(e)}>
          {
             UGDegree.map(degree=>{
                return <option value={degree.ugDegree}>{degree.ugDegree}</option>
             })
           }
        </select>
        </div>
        <br/>
        </div>
        <div class="signup">
        <div className="form">
        <label for="degree"> PG Degree :</label>
        <select name="pgDegree" id="degree" section="educationAndCareer" onChange={(e)=>captureSignInInfo(e)}>
           {
             PGDegree.map(degree=>{
                return  <option value={degree.pgDegree}>{degree.pgDegree}</option>
             })
           }
        </select>
        </div>
        <br/>
        </div>
        <div class="signup">
        <div className="form">
            Employeed :<input type="radio" name="employeeIn" section="educationAndCareer" value={true} onChange={(e)=>captureSignInInfo(e)}/>
            <label for="emp">Yes</label>
            <input type="radio" name="emp" value={false}/>
            <label for="emp">No</label>
            <br />
            </div>
        </div>
        <div class="signup">
        <div className="form">
        <label for="company"> Company :</label>
        <select name="company" id="company" section="educationAndCareer" onChange={(e)=>captureSignInInfo(e)}>
           {
            companies.map(company=>{
                return  <option value={company.companyName}>{company.companyName}</option>
            })
           }
        </select>
        </div>
        <br/>
        </div>
        <div class="signup">
        <div className="form">
        <label for="income"> Income :</label>
        <select name="income" id="income" section="educationAndCareer" onChange={(e)=>captureSignInInfo(e)}>
            {
                familyIncome.map(incobj=>{
                    return <option value={incobj.income}>{incobj.income}</option>
                })
            }
        </select>
        </div>
        <br/>
        </div>
        <div class="signup">
            <h2>DESIRED PARTNER</h2>
            <div className="form">
        <label for="age"> Age :</label>
        <select name="age" id="age" section="desiredPartner" onChange={(e)=>captureSignInInfo(e)}>
        <option>Select age</option>
            {
                Age.map(ageobj=>{
                    return  <option value={ageobj.age}>{ageobj.age}</option>
                })
            }
        </select>
        </div>
        <br/>
        </div>
        <div class="signup">
        <div className="form">
        Height :<input type="number" name="height" section="desiredPartner" onChange={(e)=>captureSignInInfo(e)}/></div><br/>
        </div>
        <div class="signup">
        <div className="form">
        <label for="maritalStatus"> Marital Status :</label>
        <select name="maritalStatus" id="maritalStatus" section="desiredPartner" onChange={(e)=>captureSignInInfo(e)}>
            <option>Select Status</option>
             {
                MaritalStatus.map(maritalobj=>{
                    return <option value={maritalobj.maritalStatus}>{maritalobj.maritalStatus}</option>
                })
             }
       </select>
       </div>
        <br/>
        </div>
        <div class="signup">
        <div className="form">
        <label for="religion"> Religion :</label>
        <select name="religion" id="religion" section="desiredPartner" onChange={(e)=>captureSignInInfo(e)}>
            <option>Select Religion</option>
            {
                Religion.map(relobj=>{
                    return  <option value={relobj.religion}>{relobj.religion}</option>
                })
            }
        </select>
        </div>
        <br/>
        </div>
        <div class="signup">
        <div className="form">
        <label for="caste"> Caste :</label>
        <select name="caste" id="caste" section="desiredPartner" onChange={(e)=>captureSignInInfo(e)}>
            {
                castes.map(caste => {
                    return <option value={caste.casteName}>{caste.casteName}</option>
                })
             }
        </select>
        </div>
        <br/>
        </div>
        <div class="signup">
        <div className="form">
        <label for="motherTongue"> Mother Tongue :</label>
        <select name="motherTongue" id="motherTongue" section="desiredPartner" onChange={(e)=>captureSignInInfo(e)}>
            <option>Select Language</option>
            {
                motherTongues.map(motherTongue=>{
                    return  <option value={motherTongue.motherTongueName}>{motherTongue.motherTongueName}</option>
                })
            }
        </select>
        </div>
        <br/>
        </div>
        <div class="signup">
        <div className="form">
        <label for="income"> Income :</label>
        <select name="income" id="income" section="desiredPartner" onChange={(e)=>captureSignInInfo(e)}>
            {
                familyIncome.map(incobj=>{
                    return  <option value={incobj.income}>{incobj.income}</option>
                })
            }
        </select>  
        </div>
        <br/>
        </div>
        </div>
        </div>
        <div class="signup">
            <div className="s11">
       <center> <button class="button" type="submit" onClick={()=>captureSignInInfo()} >Submit</button></center></div>
        </div>
        </div> */}
        </>
    )
}
export default SignupComponemt