import React, { useState } from 'react';
import "./RegistrationComponent.css";
const RegistrationForm = () => {
return (
    <>
  <div class="container">
    <div class="title">Registration</div>
    <div class="content">
      <form action="#">
        <div class="user-details">
        <div class="gender-details">
            <span class="gender-title">Gender</span>
          <input type="radio" name="gender" id="dot-1" />
          <input type="radio" name="gender" id="dot-2" />
          
          <div class="category">
            <label for="dot-1">
            <span class="dot one"></span>
            <span class="gender">Male</span>
          </label>
          <label for="dot-2">
            <span class="dot two"></span>
            <span class="gender">Female</span>
          </label>
          </div>
        </div>
          <div class="input-box">
            <span class="details">Bride/Groom Name</span>
            <input type="text" placeholder="Enter your name" required />
          </div>
          <div class="input-box">
            <span class="details">Email</span>
            <input type="text" placeholder="Enter your email" required />
          </div>
          <div class="input-box">
  <span class="details">Martial Status</span>
  <select required>
    <option value="">---- Select Martial Status ----</option>
    <option value="married">Married</option>
    <option value="unmarried">Unmarried</option>
  </select>
</div>
          <div class="input-box">
            <span class="details">Phone Number</span>
            <input type="text" placeholder="Enter your number" required />
          </div>
          <div class="input-box">
            <span class="details">Location</span>
            <input type="text" placeholder="Enter your location" required />
          </div>
          <div class="input-box">
            <span class="details">Mother tongue</span>
            <input type="text" placeholder="Enter your mother tongue" required />
          </div>
          <div class="input-box">
            <span class="details">Caste</span>
            <input type="text" placeholder="Enter your caste" required />
          </div>
        </div>
        
        <div class="button">
          <input type="submit" value="Register" />
        </div>
      </form>
    </div>
  </div>
</>
)
}
export default RegistrationForm;
