import React from "react";
import ReactModal from "react-modal";
import FooterComponent from "./footer-component";

const ModalComponent = (props) =>{
    const {open} = props;
    return(
        <ReactModal isOpen={props.open} onRequestClose={props.close}>
            Hello there
            <FooterComponent />
        </ReactModal>
    )
}
export default ModalComponent