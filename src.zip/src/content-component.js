import React, {useState} from "react";
import ModalComponent from "./modalComponent";
import ModalComponent1 from "./modalComponent1";

const ContentComponent = () =>{
    const [openModal, setOpenModal] = useState(false);
    const openModalFunction = () =>{
        setOpenModal(true);
    }
    const closeModal = () =>{
        setOpenModal(false);
    }
    return(
        <div>
            {/* <img src='bg.jpg'  /> */}
        {/* <h1>
    
        </h1>
        <button onClick={()=>openModalFunction()}>login modal</button>
        <ModalComponent1 open={openModal} close={closeModal} /> */}
        </div>
    )
}
export default ContentComponent;