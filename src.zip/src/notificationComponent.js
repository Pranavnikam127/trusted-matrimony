import React, { useEffect, useState } from "react";
import LandingHeader from "./LandingPage/LandingContain/LandingHeader/LandingHeader";
import LandingFooter from "./LandingPage/LandingContain/LandingFooter/LandingFooter";
import "./notificationComponent.css";
import { Trash } from 'react-bootstrap-icons';
const NotifictionComponent = () =>{
    const [notification, setNotification] = useState();
    useEffect(()=>{
        let notificationObj = JSON.parse(localStorage.getItem("sender"));
        setNotification(notificationObj);
    },[])
    const handleDelete = (index,e) => {
        let notificationObj = JSON.parse(localStorage.getItem("sender"));
        notificationObj.splice(index, 1);
        setNotification(notificationObj);
        localStorage.setItem("sender", JSON.stringify(notificationObj));
         //e.target.parentNode.parentNode.parentNode.deleteRow(index+1)
    }
    const createSubstring = (param) =>{
       return param.substring(0, param.indexOf("T"));
    }
    return(
        <div className="Notification-Main-Page">
        <div className="Notification-Header">
        <LandingHeader />
        </div>
        <div className="Notification-Content-Body">
            <table border="2" className="Notification-Table">
                {console.log(notification && notification)}
                    <tr>    
                    <th>Sr. No</th>
                    <th>Date</th>
                    <th>Sent By</th>
                    <th>Sender Name</th>
                    <th>Accept</th>
                    <th>Delete</th>
                    </tr>
                    { notification && notification.map((notification, index)=>{
                      return <>
                       <tr>
                       <th>{index + 1}</th>
                       <th>{notification.date.substring(0,notification.date.indexOf("T"))}</th>
                       <th>{notification.sentBy}</th>
                       <th>{notification.senderName}</th>
                       <th>{notification.accept}</th>
                       <th><button onClick={(e)=>handleDelete(index,e)}><Trash /></button></th>
                       </tr>
                       </>
                    })}
            </table>
            </div>
        <div className="Notification-Footer">
        <LandingFooter />
        </div>
        </div>    
    ) 
}
export default NotifictionComponent
