import React from "react";

const LoginModal =()=>{
    
  return(
        <h1>  This is login component</h1>  
  )
}
export default LoginModal