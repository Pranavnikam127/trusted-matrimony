import React from "react";
import ReactModal from "react-modal";
import ParentComponent from "./Parent-Component";
import LoginComponent from "./classComponent/loginComponent";
import SignupComponemt from "./classComponent/signUpComponent/signupComponent";

const ModalComponent1 =(props)=>{
      const {open}=props;
    return(
        <ReactModal isOpen={props.open} onRequestClose={()=>props.close(false)}>
         {props.type === "Sign In" && 
         <SignupComponemt />
         }
         {props.type === "Log In" && 
         <LoginComponent />
         }
        </ReactModal>
    )
}

export default ModalComponent1