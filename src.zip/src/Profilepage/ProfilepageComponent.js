import React, {useState, useEffect} from "react";
import { useParams } from "react-router-dom";
import { candidates } from "../classComponent/dummyData/candidatesProfile";
import LandingFooter from "../LandingPage/LandingContain/LandingFooter/LandingFooter";
import LandingHeader from "../LandingPage/LandingContain/LandingHeader/LandingHeader";
import "./ProfileComponent.css";
const ProfilePageComponent = () =>{
   const params = useParams();
   const newCandidates = candidates;
   const [profile, setProfile] = useState();
   const [profileObj, setProfileObj] = useState()
   console.log(params)
   useEffect(()=>{
     filterProfile(params.id)
   },[])
   const filterProfile = (id) =>{
      let profile = newCandidates.filter((candidate)=>{
         return candidate.id === id;
      });
      setProfile(profile[0]);
      setProfileObj(profile[0]);
   }
   const sendInterest = () =>{
    let userObject = JSON.parse(localStorage.getItem("userObj"));
    let interestObj = {
        date: new Date(),
        sentBy: userObject.id,
        senderName:userObject.name
    }
    let sender = localStorage.getItem("sender") ? JSON.parse(localStorage.getItem("sender")) : [];
    sender.push(interestObj)
    localStorage.setItem("sender", JSON.stringify(sender));
    alert("Your Interest Has Been Sent");
   }
  
    return(
        <>
        <LandingHeader />
        <div className="Profile-Main-Content">
            <div className="Profile-Body-Content">
            <div className="Profile1">
            <img src={profile && profile.photo} />
            </div>
            <div className="Profile2">
            Name: {profile && profile.name}
            </div>
            <div className="Profile3">
            Age: {profile && profile.age}
            </div>
            <div className="Profile4">
            <button onClick={()=>sendInterest()}>Interested</button>
            </div>
            </div>
            <div className="Profile-Body-Main">
            <div className="Family-Background">
            <h2>Family Background</h2>
            Father's Occupation:
            <h4>{profile && profile.familyBackground.fatherOccupation}</h4>
            Mother's Occupation :
            <h4>{profile && profile.familyBackground.motherOccupation}</h4>
            Gotra:
            <h4>{profile && profile.familyBackground.gotra}</h4>
            Family Income:
            <h4>{profile && profile.familyBackground.familyIncome}</h4>
            Family Values :
            <h4>{profile && profile.familyBackground.familyValues}</h4>
            No Of Sisters :
            <h4>{profile && profile.familyBackground.noOfSisters}</h4>
            No Of Brothers:
            <h4>{profile && profile.familyBackground.noOfBrothers}</h4>
            </div>
            <div className="Education-And-Carrer">
                <h2>Education and Career</h2>
            Highest Education :
            <h5>{profile && profile.educationAndCareer.highestEducation}</h5> 
            UG Degree:
            <h5>{profile && profile.educationAndCareer.ugDegree}</h5> 
            PG Degree:
            <h5>{profile && profile.educationAndCareer.pgDegree}</h5> 
            Employee In:
            <h5>{profile && profile.educationAndCareer.employeeIn}</h5> 
            Company Name:
            <h5>{profile && profile.educationAndCareer.company}</h5>            
            </div>
            <div className="Desired-Partner">
               <h2> Desired Parter</h2>
               Age:
             <h5>{profile && profile.desiredPartner.age}</h5>
              Height:
             <h5>{profile && profile.desiredPartner.height}</h5>
             Maratial Status :
             <h5>{profile && profile.desiredPartner.maratialStatus}</h5>
            Religion:
            <h5>{profile && profile.desiredPartner.religion}</h5>
            Caste:
            <h5>{profile && profile.desiredPartner.caste}</h5>
            Mother Tongue:
            <h5>{profile && profile.desiredPartner.motherTongue}</h5>
            Income:
            <h5>{profile && profile.desiredPartner.income}</h5>
            </div>
            </div>     
        </div>
        <div className="landing-footer-main">
        <LandingFooter/>
        </div>
        </>
    )
}
export default ProfilePageComponent;