import React from "react";
import ContentComponent from "./content-component";
import FooterComponent from "./footer-component";
import HeaderComponent from "./header-component";

const ParentComponent = ()=>{
    return(
        <div className="parent-component-class">
        {/* <h1>This is parent Component</h1> */}
        <HeaderComponent />
        <ContentComponent />
        <FooterComponent />
        </div>
    )
}
export default ParentComponent;