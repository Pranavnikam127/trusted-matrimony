import React, { useEffect, useState } from "react";
import HeaderComponent from "./header-component";
import FooterComponent from "./footer-component";
import { Link } from "react-router-dom";
import { candidates } from "./classComponent/dummyData/candidatesProfile";
import { ageFilter } from "./classComponent/dummyData/filterInfo";
import { religionInfo } from "./classComponent/dummyData/filterInfo";
import { occFilter } from "./classComponent/dummyData/filterInfo";
import { eduFilter } from "./classComponent/dummyData/filterInfo";
import { manglikInfo } from "./classComponent/dummyData/filterInfo";
const FlexComponent = () =>{
    const [profiles, setProfiles] = useState();
    const [ages, setAges] = useState();
    const captureChange = (e) =>{
        console.log(e.target.name);
       let newProfiles = profiles && profiles.filter((candidate)=>{
        return candidate[e.target.name] === e.target.value;
       });
       setProfiles(newProfiles);
    }
    useEffect(()=>{
        setProfiles(candidates);
        localStorage.setItem("userObj",JSON.stringify({name:"pranav", id:125}));
        localStorage.setItem("userObj",JSON.stringify({name:"kalyani", id:126}));
    },[])
    const captureAge = (e) =>{
        console.log(e.target.value)
        let newAges = candidates.filter((candidate)=>{
            return candidate[e.target.age] === e.target.value;
        });
        setAges(newAges);
    } 
    const myFunction = () => {
        return <div>
        var firstNumber = age.substring(0,age.indexOf("t")-1);
        var secondNumber = parseInt(age.substring(age.indexOf("o")+2));
        </div>
    }
    return(
        <>
        <HeaderComponent />
        <div className="flexcontainer">
            <div className="fitem1">
                <div className="f1">
                <label for="age">Age:</label>
                <select name="age" id="age" onChange={(e)=>captureAge(e)}>
                    {
                        ageFilter && ageFilter.map((agee, index) => {
                            return <option id={"i" + (index+1)} value={agee.age}>{agee.age}</option>
                        })
                    }
                </select></div><br />
                <div className="f2">
                <label for="rel">Religion:</label>
                <select name="rel" id="rel">
                    {
                     religionInfo && religionInfo.map((religion, index) => {
                            return <option id={"i" + (index+1)} name={religion}>{religion}</option>
                     })   
                    }
                </select></div><br />
                <div className="f3">
                <label for="occ">Occupation:</label>
                <select name="occupation" id="occ" onChange={(e)=>captureChange(e)}>
                    <option>Select Occupation</option>
                    {
                    occFilter && occFilter.map((occupation, index) => {
                        return <option id={"i" + (index+1)} value={occupation}>{occupation}</option>
                     })
                    }
                </select></div><br />
                <div className="f4">
                <label for="edu">Education:</label>
                <select name="edu" id="edu">
                    {
                        eduFilter && eduFilter.map((education, index) => {
                            return <option id={"i" + (index+1)} name={education}>{education}</option>
                        })
                    }
                </select></div><br />
                <div className="f5">
                <label for="mn">M/N:</label>
                {
                    manglikInfo && manglikInfo.map((item) => {
                        return <>
                        <input type="radio" id={item.id} value={item.value} name={item.name} onClick={(e)=>captureChange(e)}/>
                        <label for={item.id}>{item.label}</label>
                        </>
                    })
                }
                </div>
                </div>
            <div className="fitem2">
                <div className="fi1">
            {
               profiles && profiles.map(candidate =>{
                    return <div>
                        <div className="section">
                        <img src={candidate.photo} alt={candidate.name} className="candidate-list-photo"/>
                        <Link to={`${candidate.id}`} className="candidates-link"><h4>{candidate.name}</h4></Link>
                        <h6>{candidate.occupation}</h6>
                        </div>
                        </div>
                })
            }
            </div>
            </div>
            </div>
            <FooterComponent />
        </>
    )
}
export default FlexComponent