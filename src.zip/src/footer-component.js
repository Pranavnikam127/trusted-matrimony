import React from "react"
const FooterComponent = () =>{
    return(
        <div className="footer">
        <h1><b><i>Copyrights @ZonSoftTech</i></b></h1>
        <h1><i><u>Contact us: 9322005602</u></i></h1>
        </div>

    )
}
export default FooterComponent;