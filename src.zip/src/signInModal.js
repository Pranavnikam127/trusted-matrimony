import React from "react";

const SignModal =()=>{
   
  return(
        <h1>  This is Signin component </h1>
  )
}
export default SignModal