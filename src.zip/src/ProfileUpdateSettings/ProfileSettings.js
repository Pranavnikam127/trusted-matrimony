import React from "react";
import "./ProfileSettings.css";

const ProfileSettingsPage = () => {
      return (
            <>
                  <div className="Settings-info">
                        <div className="Settings-page">
                              <div className="first-name">
                                    <label htmlFor="firstName">First Name:</label>
                                    <input type="text" id="firstName" name="firstName" />
                              </div>
                              <div className="last-name">
                                    <label htmlFor="lastName">Last Name:</label>
                                    <input type="text" id="lastName" name="lastName" />
                              </div>
                              <div className="date-of-birth">
                                    <label htmlFor="dob">Date of Birth:</label>
                                    <input type="date" id="dob" name="dob" />
                              </div>
                              <div className="religion-info">
                                    <label htmlFor="religion">Religion:</label>
                                    <input type="text" id="religion" name="religion" />
                              </div>
                              <div className="caste-info">
                                    <label htmlFor="caste">Caste:</label>
                                    <input type="text" id="caste" name="caste" />
                              </div>
                              <div className="education-info">
                                    <label htmlFor="education">Education:</label>
                                    <input type="text" id="education" name="education" />
                              </div>
                              <div className="occupation-info">
                                    <label htmlFor="occupation">Occupation:</label>
                                    <input type="text" id="occupation" name="occupation" />
                              </div>
                              <div className="phone-number">
                                    <label htmlFor="phone">Phone Number:</label>
                                    <input type="number" id="phone" name="phone" />
                              </div>
                              <div className="email-id">
                                    <label htmlFor="email">Email:</label>
                                    <input type="email" id="email" name="email" />
                              </div>
                              <div className="password-info">
                                    <label htmlFor="password">Password:</label>
                                    <input type="password" id="password" name="password" />
                              </div>
                              <div className="save-button">
                                    <button>Save Changes</button>
                              </div>
                        </div>
                  </div>
            </>
      )
}
export default ProfileSettingsPage