import React, { useState } from "react";
import ModalComponent1 from "../src/modalComponent1";
import NotifictionComponent from "./notificationComponent";
import { Link, Route, Routes} from "react-router-dom";
import { Bell, BellFill, BellSlashFill } from "react-bootstrap-icons";
const HeaderComponent = (actionParam) =>{
    const [openModal, setOpenModal] = useState(false);
    const [modalType, setModalType] = useState();
    const openCloseModal = (actionParam, type) =>{
        setModalType(type);
        setOpenModal(actionParam)
    }
    return(
        <div>
            <div className="container">
                <div className="flex-item">
                <div class="title">
                <h1 align="left">Trusted Matrimony</h1>
            </div>  
        </div>
        <div className="flex-item flexItem2">
            <div class="login">
                <h1><div className="icon"><Link to="/page2"><BellFill /></Link></div>
                <button className="btn1" onClick={()=>openCloseModal(true, "Log In")}>Login</button><button className="btn2" onClick={()=>openCloseModal(true, "Sign In")}>Sign Up</button></h1>
                </div>
            </div>
        </div>
        <ModalComponent1 open={openModal} close={openCloseModal} type={modalType}/>
        </div>
    )
}
export default HeaderComponent;