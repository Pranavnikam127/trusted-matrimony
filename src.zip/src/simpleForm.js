import React from "react";

const FormComponent=()=>{
    return(
        <div className="form1">
            <div className="form2">
            <label>Name:</label>
            <input type="text" value="name" />
            </div>
            <div className="form2">
            <label>Age:</label>
            <input type="text" value="name" />
            </div>
            <div className="form2">
            <label for="gender"> Gender :</label>
        <select name="gender" id="gender"  >
        <option>Male</option>
        <option>Female</option>
          </select>
          </div>
          <div className="form2">
            <label>Address:</label>
            <input type="text" value="name" />
            </div>
            <div className="form2">
            <label>Phone Number:</label>
            <input type="text" value="name" />
            </div>
        </div>
    )
}

export default FormComponent