import React from "react";
import "./HomepageStyle.css";
const HomepageComponent = () =>{
    return(
       <>
         <div>
        
        <header>
            <h2 class="logo">ST<img src="https://i.postimg.cc/FHW3Lsf0/Group-4287-1.png"/>RK PROTOCOL</h2>
            <ul>
                <li>Products</li>
                <li>Features</li>
                <li>Token</li>
                <li>Roadmap</li>
            </ul>
        </header>
        <div>
            <div class="title">
                Stark <span>Protocol</span>
            </div>
            <div class="text1">
                <span>Built on Near and Solana</span>
            </div>
            <div class="text1 text2">
                  <span>Lorem ipsum dolor sit amet consectetur adipisicing elit.</span>
              </div>
        </div>
    </div>
       </>
    )
}
export default HomepageComponent;