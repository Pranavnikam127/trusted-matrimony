import React, { useEffect, useState } from "react";
import DashboardHeaderComponent from "./DashboardHeader";
import { Link } from "react-router-dom";
import { candidates } from "../classComponent/dummyData/candidatesProfile";
import { ageFilter } from "../classComponent/dummyData/filterInfo";
import { religionInfo } from "../classComponent/dummyData/filterInfo";
import { occFilter } from "../classComponent/dummyData/filterInfo";
import { eduFilter } from "../classComponent/dummyData/filterInfo";
import { manglikInfo } from "../classComponent/dummyData/filterInfo";
import LandingFooter from "../LandingPage/LandingContain/LandingFooter/LandingFooter";
import "./DashboardStyle.css";
import LandingHeader from "../LandingPage/LandingContain/LandingHeader/LandingHeader";
const DashboardComponent = () =>{
    const [profiles, setProfiles] = useState();
    const [ages, setAges] = useState();
    const captureChange = (e) =>{
        console.log(e.target.name);
       let newProfiles = profiles && profiles.filter((candidate)=>{
        return candidate[e.target.name] === e.target.value;
       });
       setProfiles(newProfiles);
    }
    useEffect(()=>{
        setProfiles(candidates);
        localStorage.setItem("userObj",JSON.stringify({name:"pranav", id:125}));
        localStorage.setItem("userObj",JSON.stringify({name:"kalyani", id:126}));
    },[])
    const captureAge = (e) =>{
        console.log(e.target.value)
        let newAges = candidates.filter((candidate)=>{
            return candidate[e.target.age] === e.target.value;
        });
        setAges(newAges);
    } 
    const myFunction = () => {
        return <div>
        var firstNumber = age.substring(0,age.indexOf("t")-1);
        var secondNumber = parseInt(age.substring(age.indexOf("o")+2));
        </div>
    }
    return(
        <>
        <LandingHeader />
        <div className="Main-Flex-Container">
            <div className="Dashboard-Sidebar-Container">
                <div className="f1">
                <label for="age">Age:</label>
                <select name="age" id="age" onChange={(e)=>captureAge(e)}>
                    {
                        ageFilter && ageFilter.map((agee, index) => {
                            return <option id={"i" + (index+1)} value={agee.age}>{agee.age}</option>
                        })
                    }
                </select></div><br />
                <div className="f2">
                <label for="rel">Religion:</label>
                <select name="rel" id="rel">
                    {
                     religionInfo && religionInfo.map((religion, index) => {
                            return <option id={"i" + (index+1)} name={religion}>{religion}</option>
                     })   
                    }
                </select></div><br />
                <div className="f3">
                <label for="occ">Occupation:</label>
                <select name="occupation" id="occ" onChange={(e)=>captureChange(e)}>
                    <option>Select Occupation</option>
                    {
                    occFilter && occFilter.map((occupation, index) => {
                        return <option id={"i" + (index+1)} value={occupation}>{occupation}</option>
                     })
                    }
                </select></div><br />
                <div className="f4">
                <label for="edu">Education:</label>
                <select name="edu" id="edu">
                    {
                        eduFilter && eduFilter.map((education, index) => {
                            return <option id={"i" + (index+1)} name={education}>{education}</option>
                        })
                    }
                </select></div><br />
                <div className="f5">
                <label for="mn">M/N:</label>
                {
                    manglikInfo && manglikInfo.map((item) => {
                        return <>
                        <input type="radio" id={item.id} value={item.value} name={item.name} onClick={(e)=>captureChange(e)}/>
                        <label for={item.id}>{item.label}</label>
                        </>
                    })
                }
                </div>
                </div>
            <div className="Dashboard-Body-Container">
                <div className="fi1">
            {
               profiles && profiles.map(candidate =>{
                    return <div>
                        <div className="Dashboard-Body-Section">
                        <img src={candidate.photo} alt={candidate.name} className="candidate-list-photo"/>
                        <Link to={`${candidate.id}`} className="candidates-link">
                            <h4>Name: {candidate.name}</h4></Link>
                        <h6>Occupation: {candidate.occupation}</h6>
                        <h6>Age:{candidate.age}</h6>
                        </div>
                        </div>
                })
            }
            </div>
            </div>
            </div>
            <LandingFooter />
        </>
    )
}
export default DashboardComponent;