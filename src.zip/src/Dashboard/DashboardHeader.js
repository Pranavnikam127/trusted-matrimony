import React, { useState } from "react";
import { Link } from "react-router-dom";
import { BellFill } from "react-bootstrap-icons";
const DashboardHeaderComponent = (actionParam) =>{
    
    return(
        <div>
            <div className="container">
                <div className="flex-item">
                <div class="title">
                <h1 align="left">Trusted Matrimony</h1>
            </div>  
        </div>
        <div className="flex-item flexItem2">
            <div class="login">
                <div className="icon">
                    <Link to="/page2">
                        <BellFill />
                    </Link>
                </div>
                
                </div>
            </div>
        </div>
        
        </div>
    )
}
export default DashboardHeaderComponent;